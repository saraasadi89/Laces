package com.laces.app.mvp

interface OccView