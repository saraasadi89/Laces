package com.laces.app.sdk.model

import com.google.gson.annotations.SerializedName

data class Product(
    @SerializedName("id")
    val id: String
)